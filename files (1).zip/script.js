// ===================== HELPERS =====================
function badgeClass(status){ return 'badge badge-' + (statusColor[status] || 'gray'); }
function formatBR(dateStr){ const [y,m,d]=dateStr.split('-'); return `${d}/${m}/${y}`; }
function formatMoney(v){ return v.toLocaleString('pt-BR',{style:'currency',currency:'BRL'}); }

function showToast(msg){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(showToast._t);
  showToast._t = setTimeout(()=>t.classList.remove('show'), 2200);
}

function copyToClipboard(text){
  navigator.clipboard.writeText(text).then(()=>showToast('Dados copiados!'))
    .catch(()=>showToast('Não foi possível copiar.'));
}

function iconCopy(){ return `<svg viewBox="0 0 24 24"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>`; }
function iconEdit(){ return `<svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>`; }
function iconMore(){ return `<svg viewBox="0 0 24 24"><circle cx="12" cy="5" r="1.2" fill="currentColor" stroke="none"/><circle cx="12" cy="12" r="1.2" fill="currentColor" stroke="none"/><circle cx="12" cy="19" r="1.2" fill="currentColor" stroke="none"/></svg>`; }

// ===================== NAVEGAÇÃO =====================
document.querySelectorAll('.nav-link').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    document.querySelectorAll('.nav-link').forEach(b=>b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
    document.getElementById('page-' + btn.dataset.page).classList.add('active');
  });
});

// ===================== DATA / HEADER =====================
document.getElementById('today-chip').textContent =
  new Date().toLocaleDateString('pt-BR',{weekday:'long', day:'2-digit', month:'long'})
    .replace(/^\w/, c=>c.toUpperCase());

// ===================== PÁGINA INÍCIO =====================
function renderStats(){
  const grid = document.getElementById('stat-grid');
  const emAtendimento = clientes.filter(c=>c.status==='Em atendimento').length;
  const orcEnviados = orcamentos.filter(o=>o.status==='Enviado').length;
  const vendasFechadas = orcamentos.filter(o=>o.status==='Aprovado').length;
  const stats = [
    {label:'Total de Clientes', value: clientes.length, change:'+12%', icon:'users'},
    {label:'Em Atendimento', value: emAtendimento, change:'+3%', icon:'chat'},
    {label:'Orçamentos Enviados', value: orcEnviados, change:'+25%', icon:'file'},
    {label:'Vendas Fechadas', value: vendasFechadas, change:'+50%', icon:'check'}
  ];
  const icons = {
    users:'<svg viewBox="0 0 24 24"><circle cx="9" cy="8" r="3.2"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17.5" cy="9" r="2.5"/></svg>',
    chat:'<svg viewBox="0 0 24 24"><path d="M4 4h16a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1H9l-5 4V6a1 1 0 0 1 1-1Z" fill="none"/></svg>',
    file:'<svg viewBox="0 0 24 24"><path d="M6 3h9l4 4v14a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1Z"/></svg>',
    check:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/></svg>'
  };
  grid.innerHTML = stats.map(s=>`
    <div class="stat-card">
      <div class="stat-top"><div class="stat-icon">${icons[s.icon]}</div>${s.label}</div>
      <div class="stat-value">${s.value}</div>
      <div class="stat-change">▲ ${s.change} este mês</div>
    </div>`).join('');
}

function renderDonut(container, data, centerLabel, centerSub){
  const total = data.reduce((a,b)=>a+b.valor,0);
  let acc = 0;
  const stops = data.map(d=>{
    const start = acc/total*360; acc+=d.valor; const end = acc/total*360;
    return `${d.cor} ${start}deg ${end}deg`;
  }).join(',');
  container.innerHTML = `
    <div class="donut" style="background:conic-gradient(${stops})">
      <div class="donut-center"><b>${centerLabel}</b><span>${centerSub}</span></div>
    </div>
    <div class="legend">
      ${data.map(d=>`<div class="legend-item"><span class="legend-dot" style="background:${d.cor}"></span><span class="legend-label">${d.nome}</span><span class="legend-pct">${Math.round(d.valor/total*100)}%</span></div>`).join('')}
    </div>`;
}

function renderInicio(){
  renderStats();
  const total = clientes.length; // usa base do funil como no layout de referência
  const resumo = [
    {nome:'Fechadas', valor: orcamentos.filter(o=>o.status==='Aprovado').length, cor:'#D4A537'},
    {nome:'Em negociação', valor: clientes.filter(c=>c.status==='Em negociação').length, cor:'#4FA3F7'},
    {nome:'Proposta', valor: clientes.filter(c=>c.status==='Proposta').length, cor:'#B694F5'},
    {nome:'Sem retorno', valor: Math.max(clientes.filter(c=>c.status==='Sem retorno').length,0.001), cor:'#4A4E5C'}
  ];
  const sum = resumo.reduce((a,b)=>a+b.valor,0);
  renderDonut(document.getElementById('resumo-vendas'), resumo, resumo[0].valor, 'fechadas');

  const metaAtual = orcamentos.filter(o=>o.status==='Aprovado').length;
  const metaAlvo = 20;
  document.getElementById('meta-mes').innerHTML = `
    <div class="meta-numbers"><b>${metaAtual} / ${metaAlvo}</b><span>${Math.round(metaAtual/metaAlvo*100)}%</span></div>
    <div class="progress-track"><div class="progress-fill" style="width:${metaAtual/metaAlvo*100}%"></div></div>
    <div class="meta-quote"><svg viewBox="0 0 24 24" width="18" height="18"><path d="M2 19h20l-1.6-8.5-4.2 3.3L12 6l-4.2 7.8-4.2-3.3L2 19z" fill="currentColor"/></svg>Disciplina hoje, vendas amanhã.</div>`;
}

// ===================== TABELAS GENÉRICAS =====================
function populateStatusFilter(sel, list, key){
  const values = [...new Set(list.map(i=>i[key]))];
  sel.innerHTML = '<option value="">Todos</option>' + values.map(v=>`<option value="${v}">${v}</option>`).join('');
}

function rowCopyText(obj){
  return Object.entries(obj).map(([k,v])=>`${k}: ${v}`).join('\n');
}

function renderClientes(){
  const search = document.querySelector('[data-search="clientes"]').value.toLowerCase();
  const status = document.querySelector('[data-filter-status="clientes"]').value;
  const from = document.querySelector('[data-date-from="clientes"]').value;
  const to = document.querySelector('[data-date-to="clientes"]').value;

  const rows = clientes.filter(c=>{
    const matchSearch = !search || c.nome.toLowerCase().includes(search) || c.telefone.includes(search) || c.cidade.toLowerCase().includes(search);
    const matchStatus = !status || c.status === status;
    const matchFrom = !from || c.ultimoContato >= from;
    const matchTo = !to || c.ultimoContato <= to;
    return matchSearch && matchStatus && matchFrom && matchTo;
  });

  document.querySelector('#tbl-clientes tbody').innerHTML = rows.map(c=>`
    <tr>
      <td>${c.nome}</td><td>${c.telefone}</td><td>${c.cidade}</td>
      <td><span class="${badgeClass(c.status)}">${c.status}</span></td>
      <td>${formatBR(c.ultimoContato)}</td>
      <td class="row-actions">
        <button class="btn-icon" title="Copiar dados" onclick='copyToClipboard(${JSON.stringify(rowCopyText(c)).replace(/'/g,"&#39;")})'>${iconCopy()}</button>
        <button class="btn-icon" title="Editar">${iconEdit()}</button>
        <button class="btn-icon" title="Mais">${iconMore()}</button>
      </td>
    </tr>`).join('') || `<tr><td colspan="6" style="text-align:center;color:var(--text-3);padding:26px">Nenhum cliente encontrado.</td></tr>`;
}

function renderContatos(){
  const search = document.querySelector('[data-search="contatos"]').value.toLowerCase();
  const status = document.querySelector('[data-filter-status="contatos"]').value;
  const origem = document.querySelector('[data-filter-origem="contatos"]').value;

  const rows = contatos.filter(c=>{
    const matchSearch = !search || c.nome.toLowerCase().includes(search) || c.telefone.includes(search) || c.origem.toLowerCase().includes(search);
    const matchStatus = !status || c.status === status;
    const matchOrigem = !origem || c.origem === origem;
    return matchSearch && matchStatus && matchOrigem;
  });

  document.querySelector('#tbl-contatos tbody').innerHTML = rows.map(c=>`
    <tr>
      <td>${c.nome}</td><td>${c.telefone}</td><td>${c.origem}</td>
      <td><span class="${badgeClass(c.status)}">${c.status}</span></td>
      <td class="row-actions">
        <button class="btn-icon" title="Copiar dados" onclick='copyToClipboard(${JSON.stringify(rowCopyText(c)).replace(/'/g,"&#39;")})'>${iconCopy()}</button>
        <button class="btn-icon" title="Editar">${iconEdit()}</button>
        <button class="btn-icon" title="Mais">${iconMore()}</button>
      </td>
    </tr>`).join('') || `<tr><td colspan="5" style="text-align:center;color:var(--text-3);padding:26px">Nenhum contato encontrado.</td></tr>`;
}

function renderOrcamentos(){
  const search = document.querySelector('[data-search="orcamentos"]').value.toLowerCase();
  const status = document.querySelector('[data-filter-status="orcamentos"]').value;
  const from = document.querySelector('[data-date-from="orcamentos"]').value;
  const to = document.querySelector('[data-date-to="orcamentos"]').value;

  const rows = orcamentos.filter(o=>{
    const matchSearch = !search || o.cliente.toLowerCase().includes(search) || o.produto.toLowerCase().includes(search) || o.numero.includes(search);
    const matchStatus = !status || o.status === status;
    const matchFrom = !from || o.data >= from;
    const matchTo = !to || o.data <= to;
    return matchSearch && matchStatus && matchFrom && matchTo;
  });

  document.querySelector('#tbl-orcamentos tbody').innerHTML = rows.map(o=>`
    <tr>
      <td>${o.numero}</td><td>${o.cliente}</td><td>${o.produto}</td><td>${formatMoney(o.valor)}</td>
      <td><span class="${badgeClass(o.status)}">${o.status}</span></td>
      <td>${formatBR(o.data)}</td>
      <td class="row-actions">
        <button class="btn-icon" title="Copiar dados" onclick='copyToClipboard(${JSON.stringify(rowCopyText(o)).replace(/'/g,"&#39;")})'>${iconCopy()}</button>
        <button class="btn-icon" title="Editar">${iconEdit()}</button>
        <button class="btn-icon" title="Mais">${iconMore()}</button>
      </td>
    </tr>`).join('') || `<tr><td colspan="7" style="text-align:center;color:var(--text-3);padding:26px">Nenhum orçamento encontrado.</td></tr>`;
}

// liga eventos de busca/filtro
document.querySelectorAll('[data-search]').forEach(el=>el.addEventListener('input', ()=>renderAll(el.dataset.search)));
document.querySelectorAll('[data-filter-status],[data-filter-origem],[data-date-from],[data-date-to]').forEach(el=>{
  const key = el.dataset.filterStatus || el.dataset.filterOrigem || el.dataset.dateFrom || el.dataset.dateTo;
  el.addEventListener('input', ()=>renderAll(key));
  el.addEventListener('change', ()=>renderAll(key));
});
function renderAll(which){
  if(which==='clientes') renderClientes();
  if(which==='contatos') renderContatos();
  if(which==='orcamentos') renderOrcamentos();
}

// ===================== FUNIL =====================
function renderFunil(){
  const max = funilEtapas[0].valor;
  document.getElementById('funnel').innerHTML = funilEtapas.map(e=>`
    <div class="funnel-stage" style="width:${40 + (e.valor/max)*55}%">
      ${e.nome}<small>${e.valor} &nbsp;·&nbsp; ${Math.round(e.valor/max*100)}%</small>
    </div>`).join('');

  const fechadas = funilEtapas[funilEtapas.length-1].valor;
  const inicial = funilEtapas[0].valor;
  renderDonut(document.getElementById('conversao'),
    [{nome:'Convertidos', valor: fechadas, cor:'#D4A537'},{nome:'Não convertidos', valor: inicial-fechadas, cor:'#232838'}],
    Math.round(fechadas/inicial*100)+'%', `${fechadas} de ${inicial} leads viraram vendas`);

  document.getElementById('media-mes').innerHTML = `
    <div class="meta-numbers"><b>${fechadas} / 20</b><span>${Math.round(fechadas/20*100)}%</span></div>
    <div class="progress-track"><div class="progress-fill" style="width:${fechadas/20*100}%"></div></div>`;
}

// ===================== RELATÓRIOS =====================
function renderRelatorios(){
  const totalVendas = orcamentos.filter(o=>o.status==='Aprovado').reduce((a,b)=>a+b.valor,0);
  const stats = [
    {label:'Vendas', value: formatMoney(totalVendas), change:'+28%'},
    {label:'Orçamentos', value: orcamentos.length, change:'+25%'},
    {label:'Clientes Novos', value: clientes.length, change:'+43%'},
    {label:'Ticket Médio', value: formatMoney(totalVendas/(orcamentos.filter(o=>o.status==='Aprovado').length||1)), change:'+16%'}
  ];
  document.getElementById('rel-stat-grid').innerHTML = stats.map(s=>`
    <div class="stat-card">
      <div class="stat-top">${s.label}</div>
      <div class="stat-value">${s.value}</div>
      <div class="stat-change">▲ ${s.change}</div>
    </div>`).join('');

  const max = Math.max(...vendasPeriodo.map(v=>v.valor));
  document.getElementById('vendas-periodo').innerHTML = vendasPeriodo.map(v=>`
    <div class="bar-col"><div class="bar" style="height:${v.valor/max*100}%"></div><div class="bar-label">${v.dia}</div></div>`).join('');

  renderDonut(document.getElementById('origem-contatos'), origemContatos, origemContatos[0].valor+'%', origemContatos[0].nome);
}

// ===================== IMPORTAR PDF / EXCEL =====================
if (window['pdfjsLib']) {
  pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
}

let importTarget = null;
let importedRows = [];

document.querySelectorAll('[data-import]').forEach(btn=>{
  btn.addEventListener('click', ()=>{
    importTarget = btn.dataset.import;
    importedRows = [];
    document.getElementById('import-preview').innerHTML = '';
    document.getElementById('dropzone-text').textContent = 'Clique para escolher um arquivo ou arraste aqui';
    document.getElementById('import-confirm').disabled = true;
    document.getElementById('import-modal').classList.remove('hidden');
  });
});
document.getElementById('modal-close').onclick =
document.getElementById('import-cancel').onclick = ()=>document.getElementById('import-modal').classList.add('hidden');

document.getElementById('dropzone').addEventListener('dragover', e=>e.preventDefault());
document.getElementById('dropzone').addEventListener('drop', e=>{
  e.preventDefault();
  if(e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0]);
});
document.getElementById('file-input').addEventListener('change', e=>{
  if(e.target.files[0]) handleFile(e.target.files[0]);
});

function handleFile(file){
  document.getElementById('dropzone-text').textContent = file.name;
  const ext = file.name.split('.').pop().toLowerCase();
  if(ext === 'csv' || ext === 'xlsx' || ext === 'xls'){
    const reader = new FileReader();
    reader.onload = e=>{
      const wb = XLSX.read(e.target.result, {type:'binary'});
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const json = XLSX.utils.sheet_to_json(sheet, {defval:''});
      importedRows = json;
      showPreview(json);
    };
    reader.readAsBinaryString(file);
  } else if(ext === 'pdf'){
    const reader = new FileReader();
    reader.onload = async e=>{
      try{
        const pdf = await pdfjsLib.getDocument({data:e.target.result}).promise;
        let lines = [];
        for(let p=1;p<=pdf.numPages;p++){
          const page = await pdf.getPage(p);
          const content = await page.getTextContent();
          const text = content.items.map(i=>i.str).join(' ');
          lines.push(...text.split(/\n|(?<=\.)\s{2,}/).filter(Boolean));
        }
        importedRows = lines.filter(l=>l.trim()).map(l=>({texto: l.trim()}));
        showPreview(importedRows);
      }catch(err){
        document.getElementById('import-preview').innerHTML = `<p style="color:var(--red)">Não foi possível ler este PDF.</p>`;
      }
    };
    reader.readAsArrayBuffer(file);
  }
}

function showPreview(rows){
  if(!rows.length){
    document.getElementById('import-preview').innerHTML = '<p class="sub">Nenhum dado encontrado no arquivo.</p>';
    document.getElementById('import-confirm').disabled = true;
    return;
  }
  const cols = Object.keys(rows[0]);
  document.getElementById('import-preview').innerHTML = `
    <table><thead><tr>${cols.map(c=>`<th>${c}</th>`).join('')}</tr></thead>
    <tbody>${rows.slice(0,8).map(r=>`<tr>${cols.map(c=>`<td>${r[c]}</td>`).join('')}</tr>`).join('')}</tbody></table>
    <p class="sub" style="margin-top:8px">${rows.length} registro(s) encontrado(s)${rows.length>8?' — mostrando 8':''}.</p>`;
  document.getElementById('import-confirm').disabled = false;
}

document.getElementById('import-confirm').addEventListener('click', ()=>{
  if(!importedRows.length) return;
  if(importTarget === 'clientes'){
    importedRows.forEach(r=>clientes.push({
      nome: r.Nome || r.nome || r.texto || 'Sem nome',
      telefone: r.Telefone || r.telefone || '-',
      cidade: r.Cidade || r.cidade || '-',
      status: r.Status || r.status || 'Contato inicial',
      ultimoContato: new Date().toISOString().slice(0,10)
    }));
    renderClientes();
  } else if(importTarget === 'contatos'){
    importedRows.forEach(r=>contatos.push({
      nome: r.Nome || r.nome || r.texto || 'Sem nome',
      telefone: r.Telefone || r.telefone || '-',
      origem: r.Origem || r.origem || 'Site',
      status: r.Status || r.status || 'Novo contato'
    }));
    renderContatos();
  } else if(importTarget === 'orcamentos'){
    importedRows.forEach((r,i)=>orcamentos.push({
      numero: r.Numero || r.numero || String(orcamentos.length+1).padStart(4,'0'),
      cliente: r.Cliente || r.cliente || r.texto || 'Sem cliente',
      produto: r.Produto || r.produto || '-',
      valor: Number(r.Valor || r.valor || 0),
      status: r.Status || r.status || 'Enviado',
      data: new Date().toISOString().slice(0,10)
    }));
    renderOrcamentos();
  }
  document.getElementById('import-modal').classList.add('hidden');
  showToast(`${importedRows.length} registro(s) adicionado(s)!`);
});

// ===================== INIT =====================
populateStatusFilter(document.querySelector('[data-filter-status="clientes"]'), clientes, 'status');
populateStatusFilter(document.querySelector('[data-filter-status="contatos"]'), contatos, 'status');
populateStatusFilter(document.querySelector('[data-filter-origem="contatos"]'), contatos, 'origem');
populateStatusFilter(document.querySelector('[data-filter-status="orcamentos"]'), orcamentos, 'status');

renderInicio();
renderClientes();
renderContatos();
renderOrcamentos();
renderFunil();
renderRelatorios();
